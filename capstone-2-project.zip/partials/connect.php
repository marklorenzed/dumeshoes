<?php 
	$host = "localhost";
	$username = "root";
	$password = "";
	$dbname = "CP2_DUMA";

	$conn = mysqli_connect($host, $username, $password, $dbname);
 ?>