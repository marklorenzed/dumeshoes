INSERT INTO products(productName,price,img_path, category_id)
VALUES("Badolla Black",6900,"assets/img/dress_shoes/badolla_black1.jpg",1);



INSERT INTO products(productName,price,img_path, category_id)
VALUES("Badolla Cognac",6900,"assets/img/dress_shoes/badolla_cognac1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Badolla Midnight",6900,"assets/img/dress_shoes/badolla_midnightblack1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Clintunn Cognac",5900,"assets/img/dress_shoes/clintunn/clintunn_cognac1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Clintunn Dark Brown",5900,"assets/img/dress_shoes/clintunn/clintunn_darkbrown1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Clintunn Suede Navy",5900,"assets/img/dress_shoes/clintunn/clintunn_navy1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Clintunn Suede Black",5900,"assets/img/dress_shoes/clintunn/clintunn_suedeblack1.jpg",1);



INSERT INTO products(productName,price,img_path, category_id)
VALUES("Gregory Cognac",3900,"assets/img/dress_shoes/gregory/gregory_1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Gregory Black",3900,"assets/img/dress_shoes/gregory/gregory_black_1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Gregory Brown",3900,"assets/img/dress_shoes/gregory/gregory_brown_1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Gregory Navy",3900,"assets/img/dress_shoes/gregory/gregory_navy_1.jpg",1);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Rucksack Black",3900,"assets/img/bags/rucksack_black1.jpg",3);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Rucksack Tan",3900,"assets/img/bags/rucksack_tan1.jpg",3);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Rucksack Wine",3900,"assets/img/bags/rucksack_wine1.jpg",3);

INSERT INTO products(productName,price,img_path, category_id)
VALUES("Duffle Bag",3900,"assets/img/bags/duffle_black1.jpg",3);

