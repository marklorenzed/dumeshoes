<?php 
	session_start();
	include "partials/header.php";
	include "partials/connect.php"
?>
<!DOCTYPE html>
<html>
<head>
	<title>Duma's | Home</title>

</head>
<body>


<div class="container" id="index">
	<div class="row featured">
		<div class="col-6">
			
			<img class="modelImage" src="assets/img/dressShoesModel.jpg">

		</div>
		<div class="col-6">
			
			<div class="row title">
				<div class="col-12">
					<h2 class="featuredTitle">Dress Shoes</h2>
					<button class="btn btn1" type="button" onclick="redirect(1)">Shop now</button>
				</div>
			</div>

			<div class="row featuredContent">
				<div class="col-12 featuredContentWrapper">

					<h3 class="featuredSubTitle">Featured Items:</h3>

					<div class="row">
						<div class="col-6 featuredproductWrapper">
							
		                    <div data-toggle='modal'  data-target='#productModal1' id = 'product1' class='product animated fadeIn  p-0'>
		                      <img id="productImg1" class='featuredImage m-0' onmouseover = 'showName(1)' onmouseout= 'hideName(1)' src='assets/img/badolla_black1.jpg'>
		                      <p class='productName2 m-0'>Badolla Black</p>
		                      <p class='productPrice'>₱6900.00 </p>
		                      <p onmouseover = 'showName(1)' onmouseout= 'hideName(1)' id='productName1' class='productName'>Badolla Black</p>
		                   </div>
		               
						</div>
						<div class="col-6 featuredproductWrapper">
							 <div data-toggle='modal'  data-target='#productModal9' id = 'product9' class='product animated fadeIn  p-0'>
							   <img id="productImg9" class='featuredImage m-0' onmouseover = 'showName(9)' onmouseout= 'hideName(9)' src='assets/img/gregory_1.jpg'>
							   <p class='productName2 m-0'>Gregory Cognac</p>
							   <p class='productPrice'>₱3900.00 </p>
							   <p onmouseover = 'showName(9)' onmouseout= 'hideName(9)' id='productName9' class='productName'>Gregory Cognac</p>
							</div>
							
						</div>
					</div>
				</div>
			</div>			

		</div>
	</div>
	
	<div class="row featured">
		
		<div class="col-6">
			<div class="row title">
				<div class="col-12">
					<h2 class="featuredTitle">Casual Shoes</h2>
					<button class="btn btn1" type="button" onclick="redirect(1)">Shop now</button>
				</div>
			</div>
			
			<div class="row featuredContent">

				<div class="col-12 featuredContentWrapper">

					<h3 class="featuredSubTitle">Featured Items:</h3>

					<div class="row">
						<div class="col-6 featuredproductWrapper">
							
		                    <div data-toggle='modal'  data-target='#productModal25' id = 'product25' class='product animated fadeIn  p-0'>
		                      <img id="productImg25" class='featuredImage m-0' onmouseover = 'showName(25)' onmouseout= 'hideName(25)' src='assets/img/aauwen_darkgrey1.jpg'>
		                      <p class='productName2 m-0'>Aauwen Dark Grey</p>
		                      <p class='productPrice'>₱3900.00 </p>
		                      <p onmouseover = 'showName(25)' onmouseout= 'hideName(25)' id='productName25' class='productName'>Aauwen Dark Grey</p>
		                   </div>
		               
						</div>
						<div class="col-6 featuredproductWrapper">
							 <div data-toggle='modal'  data-target='#productModal26' id = 'product26' class='product animated fadeIn  p-0'>
							   <img id="productImg26" class='featuredImage m-0' onmouseover = 'showName(26)' onmouseout= 'hideName(26)' src='assets/img/dworien_navy1.jpg'>
							   <p class='productName2 m-0'>Dworien Navy</p>
							   <p class='productPrice'>₱3900.00 </p>
							   <p onmouseover = 'showName(26)' onmouseout= 'hideName(26)' id='productName26' class='productName'>Dworien Navy</p>
							</div>
							
						</div>
					</div>
				</div>
			</div>
			

		</div>

		<div class="col-6">
			
			<img class="modelImage" src="assets/img/casual_model.jpg">

		</div>
	</div>


	<div class="row featured">
		<div class="col-6">
			
			<img class="modelImage" src="assets/img/bag_model.jpg">

		</div>
		<div class="col-6">
			
			<div class="row title">
				<div class="col-12">
					<h2 class="featuredTitle">Leather Bags</h2>
					<button class="btn btn1" type="button" onclick="redirect(1)">Shop now</button>
				</div>
			</div>

			<div class="row featuredContent">
				<div class="col-12 featuredContentWrapper">

					<h3 class="featuredSubTitle">Featured Items:</h3>

					<div class="row">
						<div class="col-6 featuredproductWrapper">
							
		                    <div data-toggle='modal'  data-target='#productModal27' id = 'product27' class='product animated fadeIn  p-0'>
		                      <img id="productImg27" class='featuredImage m-0' onmouseover = 'showName(27)' onmouseout= 'hideName(27)' src='assets/img/cross_bodybag4.jpg'>
		                      <p class='productName2 m-0'>Cross Body Bag</p>
		                      <p class='productPrice'>₱1500.00 </p>
		                      <p onmouseover = 'showName(27)' onmouseout= 'hideName(27)' id='productName27' class='productName'>Cross Body Bag</p>
		                   </div>
		               
						</div>
						<div class="col-6 featuredproductWrapper">
							 <div data-toggle='modal'  data-target='#productModal15' id = 'product15' class='product animated fadeIn  p-0'>
							   <img id="productImg15" class='featuredImage m-0' onmouseover = 'showName(15)' onmouseout= 'hideName(15)' src='assets/img/rucksack_wine1.jpg'>
							   <p class='productName2 m-0'>Rucksack wine</p>
							   <p class='productPrice'>₱3900.00 </p>
							   <p onmouseover = 'showName(15)' onmouseout= 'hideName(15)' id='productName15' class='productName'>Rucksack Wine</p>
							</div>
							
						</div>
					</div>
				</div>
			</div>			

		</div>
	</div>
		

</div>
	



	


<?php 
	include "partials/footer.php";
 ?>

</body>
</html>


